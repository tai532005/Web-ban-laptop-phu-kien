// assets/js/script.js

document.addEventListener('DOMContentLoaded', () => {
    const productListContainer = document.getElementById('product-list');
    const flashProductListContainer = document.getElementById('flash-product-list');
    const flashProductsInnerWrapper = document.getElementById('flash-products-inner-wrapper'); // Wrapper mới cho carousel
    const brandListContainer = document.getElementById('brand-list');
    const productTypeListContainer = document.getElementById('product-type-list');
    const smallCategoryListContainer = document.getElementById('small-category-list');
    const decorProductListContainer = document.getElementById('decor-product-list');

    // Mảng các màu nền cho Flash Sales cards
    const flashSaleBackgroundColors = ['bg-light-blue', 'bg-light-red', 'bg-light-purple', 'bg-light-green', 'bg-light-orange', 'bg-light-pink', 'bg-light-grey', 'bg-light-cyan'];

    // Hàm để tạo các sao đánh giá
    const createStarRating = (rating) => {
        let starsHtml = '';
        // Lặp 5 lần để tạo 5 ngôi sao
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsHtml += '<i class="fas fa-star"></i>'; // Sao đầy nếu rating lớn hơn hoặc bằng i
            } else {
                starsHtml += '<i class="far fa-star"></i>'; // Sao rỗng nếu rating nhỏ hơn i
            }
        }
        return `<div class="star-rating">${starsHtml}</div>`;
    };

    // Hàm tạo thẻ sản phẩm cho Flash Sale (ít thông tin hơn)
    // Tách riêng hàm này để tạo các thẻ sản phẩm Flash Sale với cấu trúc tùy chỉnh
    function createFlashSaleProductCard(product, colorClass) {
        const productCard = document.createElement('a');
        productCard.href = `product_detail.html?id=${product.id}`;
        productCard.classList.add('product-card', colorClass); // Thêm class màu nền

        // Định dạng giá tiền mới và cũ
        const formattedNewPrice = parseFloat(product.price).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
        const formattedOldPrice = product.oldPrice ? parseFloat(product.oldPrice).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }) : '';

        productCard.innerHTML = `
            ${product.discount ? `<span class="discount-badge">-${product.discount}%</span>` : ''}
            <img src="${product.image_url}" alt="${product.name}" onerror="this.onerror=null;this.src='https://placehold.co/300x200/${colorClass.replace('bg-light-', '').toUpperCase()}/000000?text=${product.name.replace(/\s/g, '+')}';">
            <div class="product-info">
                <h3>${product.name}</h3>
                <p class="full-name">${product.fullName || ''}</p>
                <p class="new-price">${formattedNewPrice}</p>
                <p class="old-price">${formattedOldPrice}</p>
                ${createStarRating(product.rating || 0)}
                ${product.reviews ? `<span class="review-count">(${product.reviews})</span>` : ''}
                <button class="add-to-cart-btn">Thêm vào giỏ hàng</button>
            </div>
        `;

        // Bắt sự kiện click cho nút "Thêm vào giỏ hàng"
        const addToCartBtn = productCard.querySelector('.add-to-cart-btn');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', (event) => {
                event.preventDefault(); // Ngăn chặn hành vi mặc định của thẻ <a> (chuyển trang)
                alert(`Đã thêm "${product.fullName}" vào giỏ hàng! (Chức năng này sẽ được phát triển sau)`);
            });
        }
        return productCard;
    }


    // Hàm chung để render sản phẩm vào một container (không phải Flash Sale)
    const renderProducts = (products, containerElement) => { // Bỏ isFlashSale khỏi signature
        containerElement.innerHTML = ''; // Xóa nội dung cũ trong container trước khi render

        if (products.length === 0) {
            containerElement.innerHTML = '<p>Không có sản phẩm nào để hiển thị.</p>';
            return;
        }

        products.forEach(product => {
            const productCard = document.createElement('a');
            productCard.href = `product_detail.html?id=${product.id}`;
            productCard.classList.add('product-card');

            const formattedNewPrice = parseFloat(product.price).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
            const formattedOldPrice = product.oldPrice ? parseFloat(product.oldPrice).toLocaleString('vi-VN', { style: 'currency', currency: 'VND' }) : '';
            const starsHtml = createStarRating(product.rating || 0);

            productCard.innerHTML = `
                ${product.discount ? `<span class="discount-badge">-${product.discount}%</span>` : ''}
                <div class="icon-overlay">
                    <span class="icon-circle"><i class="far fa-heart"></i></span>
                    <span class="icon-circle"><i class="far fa-eye"></i></span>
                </div>
                <img src="${product.image_url}" alt="${product.name}" onerror="this.onerror=null;this.src='https://placehold.co/300x200/CCCCCC/000000?text=No+Image';">
                <div class="product-info">
                    <h3>${product.name}</h3>
                    <p class="new-price">${formattedNewPrice} ${product.oldPrice ? `<span class="old-price">${formattedOldPrice}</span>` : ''}</p>
                    ${starsHtml}
                    ${product.reviews ? `<span class="review-count">(${product.reviews})</span>` : ''}
                    <p class="description">${product.description}</p>
                    <button class="add-to-cart-btn">MUA NGAY</button>
                </div>
            `;
            containerElement.appendChild(productCard);

            const addToCartBtn = productCard.querySelector('.add-to-cart-btn');
            if (addToCartBtn) {
                addToCartBtn.addEventListener('click', (event) => {
                    event.preventDefault();
                    alert(`Đã thêm "${product.name}" vào giỏ hàng! (Chức năng này sẽ được phát triển sau)`);
                });
            }
        });
    };

    // Hàm để tải sản phẩm từ API backend cho phần "Sản phẩm của chúng tôi"
    const fetchOurProducts = async () => {
        const apiUrl = 'http://localhost/laptop_shop/api/products.php'; // Địa chỉ API của bạn

        try {
            const response = await fetch(apiUrl); // Gửi yêu cầu GET
            if (!response.ok) {
                throw new Error(`Lỗi HTTP: ${response.status}`); // Xử lý lỗi HTTP
            }
            const products = await response.json(); // Chuyển đổi phản hồi sang JSON
            renderProducts(products, productListContainer); // Render sản phẩm vào container
        } catch (error) {
            console.error('Không thể tải sản phẩm:', error);
            productListContainer.innerHTML = '<p style="color: red;">Không thể tải sản phẩm. Vui lòng kiểm tra kết nối API.</p>';
        }
    };

    // Dữ liệu mẫu cho phần "Flash Sales" (đã cập nhật)
    const flashSaleProducts = [
        {
            id: 101,
            name: "Asus Vivobook",
            fullName: "Laptop Asus Vivobook Go 15",
            price: 11490000,
            oldPrice: 14490000,
            discount: 21,
            image_url: "https://placehold.co/300x200/90CAF9/000000?text=Asus+Vivobook",
            rating: 4,
            reviews: 88
        },
        {
            id: 102,
            name: "Acer Aspire",
            fullName: "Laptop Acer Aspire 5",
            price: 15490000,
            oldPrice: 20490000,
            discount: 24,
            image_url: "https://placehold.co/300x200/F3E5F5/000000?text=Acer+Aspire",
            rating: 4.5,
            reviews: 99
        },
        {
            id: 103,
            name: "ROG Mouse",
            fullName: "Mouse - Asus ROG Gladius 2",
            price: 1150000,
            oldPrice: 2290000,
            discount: 50,
            image_url: "https://placehold.co/300x200/EF9A9A/000000?text=ROG+Mouse",
            rating: 4,
            reviews: 65
        },
        {
            id: 104,
            name: "Lenovo Yoga",
            fullName: "Laptop Lenovo Yoga Pro 7",
            price: 40990000,
            oldPrice: 46990000,
            discount: 13,
            image_url: "https://placehold.co/300x200/B2DFDB/000000?text=Lenovo+Yoga",
            rating: 5,
            reviews: 99
        },
        {
            id: 105,
            name: "MSI Creator",
            fullName: "Laptop MSI Creator M16",
            price: 49990000,
            oldPrice: 80990000,
            discount: 39,
            image_url: "https://placehold.co/300x200/FCE4EC/000000?text=MSI+Creator",
            rating: 4.5,
            reviews: 72
        },
        {
            id: 106,
            name: "HP Envy",
            fullName: "Laptop HP Envy 13",
            price: 22500000,
            oldPrice: 28000000,
            discount: 19,
            image_url: "https://placehold.co/300x200/E8F5E9/000000?text=HP+Envy",
            rating: 4.5,
            reviews: 55
        },
        {
            id: 107,
            name: "Dell XPS",
            fullName: "Laptop Dell XPS 15",
            price: 35000000,
            oldPrice: 42000000,
            discount: 17,
            image_url: "https://placehold.co/300x200/FFF3E0/000000?text=Dell+XPS",
            rating: 5,
            reviews: 70
        },
        {
            id: 108,
            name: "Logitech G213",
            fullName: "Bàn phím Logitech G213",
            price: 890000,
            oldPrice: 1200000,
            discount: 25,
            image_url: "https://placehold.co/300x200/CFD8DC/000000?text=Logitech+G213",
            rating: 4,
            reviews: 40
        }
    ];


    // Dữ liệu mẫu cho phần "Thương hiệu"
    const brands = [
        { id: 'apple', name: 'Apple', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=Apple' },
        { id: 'acer', name: 'Acer', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=Acer' },
        { id: 'asus', name: 'ASUS', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=ASUS' },
        { id: 'dell', name: 'Dell', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=Dell' },
        { id: 'hp', name: 'HP', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=HP' },
        { id: 'lenovo', name: 'Lenovo', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=Lenovo' },
        { id: 'msi', name: 'MSI', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=MSI' },
        { id: 'microsoft', name: 'Microsoft', image_url: 'https://placehold.co/100x100/FFFFFF/000000?text=Microsoft' }
    ];

    // Hàm render cho thương hiệu
    const renderBrands = (brandsData, containerElement) => {
        containerElement.innerHTML = '';
        brandsData.forEach(brand => {
            const brandCard = document.createElement('div');
            brandCard.classList.add('brand-card');
            brandCard.innerHTML = `
                <img src="${brand.image_url}" alt="${brand.name} Logo" onerror="this.onerror=null;this.src='https://placehold.co/100x100/CCCCCC/000000?text=${brand.name}';">
                <span>${brand.name}</span>
            `;
            containerElement.appendChild(brandCard);
        });
    };

    // Dữ liệu mẫu cho phần "Loại sản phẩm" (Phụ kiện)
    const productTypes = [
        { id: 'mouse', name: 'Chuột', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=Mouse' },
        { id: 'keyboard', name: 'Bàn phím', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=Keyboard' },
        { id: 'headphone', name: 'Tai nghe', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=Headphone' },
        { id: 'usb', name: 'USB', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=USB' },
        { id: 'hdd', name: 'Ổ cứng', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=HDD' },
        { id: 'monitor', name: 'Màn hình', image_url: 'https://placehold.co/150x150/EEEEEE/333333?text=Monitor' }
    ];

    // Hàm render cho loại sản phẩm
    const renderProductTypes = (typesData, containerElement) => {
        containerElement.innerHTML = '';
        typesData.forEach(type => {
            const typeCard = document.createElement('div');
            typeCard.classList.add('type-card');
            typeCard.innerHTML = `
                <img src="${type.image_url}" alt="${type.name} Icon" onerror="this.onerror=null;this.src='https://placehold.co/150x150/CCCCCC/000000?text=${type.name}';">
                <span>${type.name}</span>
            `;
            containerElement.appendChild(typeCard);
        });
    };

    // Dữ liệu mẫu cho phần "Small Categories" (CPU, Ram, etc.)
    const smallCategories = [
        { id: 'cpu', name: 'CPU', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=CPU' },
        { id: 'ram', name: 'Ram', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=RAM' },
        { id: 'storage', name: 'Ổ cứng', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=HDD' },
        { id: 'keyboard_acc', name: 'Bàn phím', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=Keyboard' },
        { id: 'mouse_acc', name: 'Chuột máy tính', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=Mouse' },
        { id: 'headphone_acc', name: 'Tai nghe', image_url: 'https://placehold.co/80x80/E0E0E0/333333?text=Headphone' }
    ];

    // Hàm render cho các danh mục nhỏ
    const renderSmallCategories = (categoriesData, containerElement) => {
        containerElement.innerHTML = '';
        categoriesData.forEach(category => {
            const categoryCard = document.createElement('div');
            categoryCard.classList.add('small-category-card');
            categoryCard.innerHTML = `
                <img src="${category.image_url}" alt="${category.name} Icon" onerror="this.onerror=null;this.src='https://placehold.co/80x80/CCCCCC/000000?text=${category.name}';">
                <span>${category.name}</span>
            `;
            containerElement.appendChild(categoryCard);
        });
    };

    // Dữ liệu mẫu cho phần "Trang trí Góc học tập, làm việc"
    const decorProducts = [
        {
            id: 201,
            name: "Chuột Gaming Logitech G502",
            price: 790000,
            oldPrice: 1390000,
            discount: 43,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Mouse+Logitech+G502",
            description: "Chuột chơi game cao cấp, tùy chỉnh RGB.",
            rating: 4.5,
            reviews: 120
        },
        {
            id: 202,
            name: "Chuột Không dây Kensou",
            price: 990000,
            oldPrice: 1890000,
            discount: 47,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Mouse+Kensou",
            description: "Chuột không dây tiện lợi, thiết kế độc đáo.",
            rating: 4,
            reviews: 90
        },
        {
            id: 203,
            name: "Chuột Gaming Logitech G Pro X Superlight",
            price: 2499000,
            oldPrice: 3599000,
            discount: 30,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Mouse+GPRO",
            description: "Chuột gaming siêu nhẹ, hiệu suất cao.",
            rating: 5,
            reviews: 150
        },
        {
            id: 204,
            name: "Bàn phím cơ Redragon Kumara K552",
            price: 1990000,
            oldPrice: 2990000,
            discount: 33,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Keyboard+Redragon",
            description: "Bàn phím cơ bền bỉ, switch quang.",
            rating: 4,
            reviews: 70
        },
        {
            id: 205,
            name: "Bàn phím cơ Fuhlen",
            price: 569000,
            oldPrice: 789000,
            discount: 27,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Keyboard+Fuhlen",
            description: "Bàn phím cơ nhỏ gọn, đèn LED.",
            rating: 3.5,
            reviews: 60
        },
        {
            id: 206,
            name: "Tai nghe Gaming HyperX Cloud Alpha S",
            price: 449000,
            oldPrice: 709000,
            discount: 36,
            image_url: "https://placehold.co/300x200/FF0000/FFFFFF?text=Headset+HyperX",
            description: "Tai nghe gaming chất lượng âm thanh vòm 7.1.",
            rating: 4.5,
            reviews: 110
        }
    ];

    // Tải sản phẩm thông thường khi trang được tải xong
    fetchOurProducts();

    // Tải thương hiệu khi trang được tải xong
    renderBrands(brands, brandListContainer);

    // Tải loại sản phẩm khi trang được tải xong
    renderProductTypes(productTypes, productTypeListContainer);

    // Tải các danh mục nhỏ khi trang được tải xong
    renderSmallCategories(smallCategories, smallCategoryListContainer);

    // Tải sản phẩm trang trí khi trang được tải xong
    renderProducts(decorProducts, decorProductListContainer);


    // Logic cho đồng hồ đếm ngược thời gian thực
    const countdownItems = document.querySelectorAll('.countdown-item span');
    const flashSaleEndTime = new Date();
    flashSaleEndTime.setDate(flashSaleEndTime.getDate() + 3); // Sale kết thúc sau 3 ngày
    flashSaleEndTime.setHours(23, 59, 59, 999); // Kết thúc vào cuối ngày thứ 3

    const updateCountdown = () => {
        const now = new Date().getTime();
        const distance = flashSaleEndTime - now;

        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((distance % (1000 * 60)) / 1000);

        if (countdownItems[0]) countdownItems[0].textContent = String(days).padStart(2, '0');
        if (countdownItems[1]) countdownItems[1].textContent = String(hours).padStart(2, '0');
        if (countdownItems[2]) countdownItems[2].textContent = String(minutes).padStart(2, '0');
        if (countdownItems[3]) countdownItems[3].textContent = String(seconds).padStart(2, '0');

        if (distance < 0) {
            clearInterval(countdownInterval);
            if (countdownItems[0]) countdownItems[0].textContent = '00';
            if (countdownItems[1]) countdownItems[1].textContent = '00';
            if (countdownItems[2]) countdownItems[2].textContent = '00';
            if (countdownItems[3]) countdownItems[3].textContent = '00';
            console.log("Flash Sale đã kết thúc!");
        }
    };

    const countdownInterval = setInterval(updateCountdown, 1000);
    updateCountdown();

    const viewAllProductsBtn = document.querySelector('.view-all-products-btn');
    if (viewAllProductsBtn) {
        viewAllProductsBtn.addEventListener('click', () => {
            alert('Chuyển đến trang xem tất cả sản phẩm Flash Sales! (Chức năng này sẽ được phát triển sau)');
        });
    }

    document.querySelectorAll('.nav-arrow').forEach(button => {
        button.addEventListener('click', (e) => {
            const parentSection = e.target.closest('section');
            if (parentSection) {
                if (e.target.classList.contains('prev-deal') || e.target.classList.contains('prev-brand') || e.target.classList.contains('prev-type') || e.target.classList.contains('prev-our-product')) {
                    alert('Chức năng lùi (previous) sẽ được phát triển sau!');
                } else if (e.target.classList.contains('next-deal') || e.target.classList.contains('next-brand') || e.target.classList.contains('next-type') || e.target.classList.contains('next-our-product')) {
                    alert('Chức năng tiến (next) sẽ được phát triển sau!');
                }
            }
        });
    });

    // --- Tự động cuộn cho Thương hiệu và Loại sản phẩm ---
    const setupAutoScroll = (container, itemSelector, scrollSpeed = 4000) => {
        let scrollInterval;

        const startScrolling = () => {
            stopScrolling();
            scrollInterval = setInterval(() => {
                const firstItem = container.querySelector(itemSelector);
                if (!firstItem) return;

                const itemWidth = firstItem.offsetWidth;
                const style = getComputedStyle(container);
                const gap = parseFloat(style.gap) || 0;
                const scrollAmount = itemWidth + gap;

                if (container.scrollLeft + container.clientWidth >= container.scrollWidth - 1) {
                    container.scrollTo({
                        left: 0,
                        behavior: 'auto'
                    });
                } else {
                    container.scrollBy({
                        left: scrollAmount,
                        behavior: 'smooth'
                    });
                }
            }, scrollSpeed);
        };

        const stopScrolling = () => {
            clearInterval(scrollInterval);
        };

        startScrolling();
        container.addEventListener('mouseenter', stopScrolling);
        container.addEventListener('mouseleave', startScrolling);
    };

    if (brandListContainer) {
        setTimeout(() => {
            setupAutoScroll(brandListContainer, '.brand-card', 4000);
        }, 500);
    }

    if (productTypeListContainer) {
        setTimeout(() => {
            setupAutoScroll(productTypeListContainer, '.type-card', 5000);
        }, 500);
    }

    // --- Logic Carousel cho Flash Sales ---
    const setupFlashSaleCarousel = (containerWrapper, productsData, visibleItemsCount = 6, slideInterval = 4000) => {
        let currentProductIndex = 0;
        let intervalId;

        // Xóa nội dung cũ
        containerWrapper.innerHTML = '';

        // Render tất cả sản phẩm gốc vào wrapper
        productsData.forEach((product, index) => {
            const colorClass = flashSaleBackgroundColors[index % flashSaleBackgroundColors.length];
            const productCard = createFlashSaleProductCard(product, colorClass);
            containerWrapper.appendChild(productCard);
        });

        // Nhân đôi số lượng sản phẩm đủ để lấp đầy khi cuộn, tạo hiệu ứng vô hạn
        // Clone đủ số lượng item để đảm bảo không bị khoảng trắng khi loop
        for (let i = 0; i < visibleItemsCount; i++) {
            const productToClone = productsData[i % productsData.length];
            const colorClass = flashSaleBackgroundColors[i % flashSaleBackgroundColors.length];
            const clonedCard = createFlashSaleProductCard(productToClone, colorClass);
            containerWrapper.appendChild(clonedCard);
        }

        const productCards = Array.from(containerWrapper.children);

        const slideNext = () => {
            const firstCard = productCards[0];
            if (!firstCard) return;

            const cardWidth = firstCard.offsetWidth;
            const style = getComputedStyle(containerWrapper);
            const gap = parseFloat(style.gap) || 0;
            const slideAmount = cardWidth + gap;

            currentProductIndex++;
            containerWrapper.style.transform = `translateX(-${currentProductIndex * slideAmount}px)`;
            containerWrapper.style.transition = 'transform 0.5s ease-in-out';

            // Khi cuộn hết các sản phẩm gốc, reset về đầu mà không có transition
            if (currentProductIndex >= productsData.length) {
                setTimeout(() => {
                    containerWrapper.style.transition = 'none';
                    currentProductIndex = 0; // Về lại vị trí đầu tiên của các sản phẩm gốc (hoặc clone tương ứng)
                    containerWrapper.style.transform = `translateX(-${currentProductIndex * slideAmount}px)`;
                    // Bật lại transition sau một khoảng thời gian nhỏ để slide tiếp theo mượt mà
                    setTimeout(() => {
                         containerWrapper.style.transition = 'transform 0.5s ease-in-out';
                    }, 50);
                }, 500); // Đợi cho transition hiện tại kết thúc (0.5s)
            }
        };

        const startAutoSlide = () => {
            stopAutoSlide(); // Xóa bất kỳ interval cũ nào
            intervalId = setInterval(slideNext, slideInterval);
        };

        const stopAutoSlide = () => {
            clearInterval(intervalId);
        };

        // Bắt đầu tự động trượt
        startAutoSlide();

        // Dừng/Tiếp tục khi hover
        containerWrapper.addEventListener('mouseenter', stopAutoSlide);
        containerWrapper.addEventListener('mouseleave', startAutoSlide);
    };

    // Áp dụng carousel cho Flash Sales
    if (flashProductsInnerWrapper) {
        // Đặt timeout nhỏ để đảm bảo các item đã render xong và có kích thước chính xác
        setTimeout(() => {
            setupFlashSaleCarousel(flashProductsInnerWrapper, flashSaleProducts, 6, 4000); // Hiển thị 6 sản phẩm, chuyển mỗi 4 giây
        }, 500);
    }

});
